const express = require("express");
const http = require("http");
const { Server } = require("socket.io");
const path = require("path");

const app = express();
const server = http.createServer(app);
const io = new Server(server, {
  cors: { origin: "*" }
});

app.use(express.static(path.join(__dirname, "public")));

// In-memory queue state
let state = {
  queue: [],
  current: null,
  avgTime: 10,
  tokenCounter: 1
};

io.on("connection", (socket) => {
  console.log("Client connected:", socket.id);

  // Send current state to newly connected client
  socket.emit("queue-updated", state);

  // Join the shared clinic room
  socket.on("join-room", () => {
    socket.join("clinic-queue");
  });

  // Receptionist: add a patient
  socket.on("add-patient", ({ name }) => {
    const token = state.tokenCounter++;
    const patientName = name?.trim() || `Patient ${token}`;
    state.queue.push({ token, name: patientName });
    io.to("clinic-queue").emit("queue-updated", state);
    console.log(`Added: Token ${token} — ${patientName}`);
  });

  // Receptionist: call next token
  socket.on("call-next", () => {
    if (state.queue.length === 0) return;
    const next = state.queue.shift();
    state.current = next;
    io.to("clinic-queue").emit("queue-updated", state);
    io.to("clinic-queue").emit("token-called", {
      token: next.token,
      name: next.name
    });
    console.log(`Called: Token ${next.token} — ${next.name}`);
  });

  // Receptionist: update avg consultation time
  socket.on("set-avg-time", ({ minutes }) => {
    state.avgTime = parseInt(minutes) || 10;
    io.to("clinic-queue").emit("queue-updated", state);
  });

  // Receptionist: clear queue
  socket.on("clear-queue", () => {
    state.queue = [];
    state.current = null;
    state.tokenCounter = 1;
    io.to("clinic-queue").emit("queue-updated", state);
    console.log("Queue cleared");
  });

  socket.on("disconnect", () => {
    console.log("Client disconnected:", socket.id);
  });
});

const PORT = process.env.PORT || 3000;
server.listen(PORT, () => {
  console.log(`Queue Cure '26 server running on http://localhost:${PORT}`);
});
